# Cheat-Menü im Ingame-Menü (Machbarkeit, 27.10.2026)

Wunsch des Projektinhabers (27.10.2026): ein Bereich „Cheats“ ganz oben auf der Seite **MANAGEMENT** des
Ingame-Menüs der App, mit Schaltern für:

1. Unendlich Gesundheit (Leon und Ashley)
2. Unendlich Munition (jede ausgerüstete Waffe)
3. One-Hit-Kill
4. Killer7 (Stufen 3/1/3/3)
5. Aktenkoffer L
6. 1.000.000 Peseten

Hintergrund: mit den EU-Discs ist das Debug-Menü des Spiels ausgeblendet (M13, Entscheidung vom 26.10.2026);
das Cheat-Menü war dafür als eigenes Vorhaben vorgesehen (`retail-eu-plan.md`). Diese Datei hält fest, was der
Spielcode dafür schon mitbringt, was neu gebaut werden müsste und wie der Projektinhaber entschieden hat (am Ende).
**Umgesetzt am 27.10.2026** (Stand und Prüfungen: `whole-program-status.md`, Abschnitt „Cheat-Menü im Ingame-Menü“).

## Ergebnis in Kürze

Alle sechs sind machbar, mit beiden Disc-Arten (der Spielcode ist in beiden Fällen der der Debug-Version).
Drei davon sind Schalter, die der Prototyp für seine Tester schon eingebaut hat. Die anderen drei sind
einmalige Änderungen am Spielstand.

| Cheat | Art | Grundlage im Spielcode | Grenzen |
| --- | --- | --- | --- |
| Unendlich Gesundheit | Schalter | `DBG_NO_DEATH` (Debug_flg Bit 72) | Sofort-Tode in Szenen bleiben (unten) |
| Unendlich Munition | Schalter | `DBG_INF_BULLET` (Bit 73) | Munitionsanzeige zeigt „100“ (behebbar) |
| One-Hit-Kill | Schalter | `DBG_EM_WEAK` (Bit 82) | einige Bosse rechnen Schaden selbst (unten) |
| Killer7 3/1/3/3 | einmalig | Gegenstand 0x2A, Stufen in `cItem::lv` | braucht Platz im Koffer; landet im Spielstand |
| Aktenkoffer L | einmalig | Gegenstand 0x7E, `SubScreenWk.board_next = 2` | nur Leon; landet im Spielstand |
| 1.000.000 Peseten | einmalig | `pG->peseta` (Obergrenze 99 999 999, `addMoney`) | nur Leon; landet im Spielstand |

## Die drei Schalter

Die Bits liegen in `GLOBAL_WK::Debug_flg` (0x60), **außerhalb** des Spielstands (0x4F80..0x8678): ein Spielstand
merkt sich nichts davon, Speichern mit eingeschaltetem Cheat verändert ihn nicht.

### Unendlich Gesundheit: `DBG_NO_DEATH`

- `LifeDownSet2` (`src/game/em_sub.cpp`) zieht Leon (`pG->pl_life`) und dem Partner (`pG->ashley_life`, auch Luis)
  den Schaden ab und füllt mit dem Bit danach wieder auf das Maximum auf. `PlSetDamage` macht aus tödlichen Treffern
  normale Treffer (Leon fällt nicht um), `cSubChar` (`pl_npc.cpp`) ebenso für Ashley.
- Einige Fallen fragen das Bit selbst: Pendel in r205 (keine Todes-Szene), Feuer gegen Ashley in r206, ein
  Angriff des Bosses em38.
- **Grenze:** Viele Gegner und Fallen setzen bei einem Fang-Angriff das Leben direkt auf 0 und starten eine
  Todes-Szene (`DiedemoExec`), ohne das Bit zu fragen: Kettensäge (`em10_R1_C_SawHit`), Würgen, Bombe im Griff,
  Klaue (em10), El Gigante (em2b), rollende Felsen (`emrock.cpp`), Lore und Gondel und weitere Bosse (gut 50
  Stellen, `grep "pl_life = 0" src`). Dort stirbt Leon
  weiter. Auch „Ashley wird weggetragen“ ist keine Frage der Gesundheit. Das abzufangen hieße, jede Szene einzeln
  umzubauen; nicht vorgesehen.
- Vorschlag: zusätzlich in jedem Bild Leben von Leon und Partner auf das Maximum setzen (harmlos, hilft bei Schaden,
  der an `LifeDownSet2` vorbei abgezogen wird).

### Unendlich Munition: `DBG_INF_BULLET`

- `cItemMgr::trigger` (`src/game/item.cpp`) verbraucht mit dem Bit nichts: Magazin bleibt voll, nie nachladen.
  Das gilt für jede ausgerüstete Waffe, auch Granaten (`pl_grenade.cpp`), den Raketenwerfer (`objRocket.cpp`
  lädt nach, der Einweg-Werfer 0x35 wird nicht weggeworfen) und Minenwerfer.
- **Schönheitsfehler:** `cItemMgr::bulletNum` meldet mit dem Bit immer 100, die Anzeige unten rechts zeigt „100“.
  Vorschlag: ein Port-Patch, damit die Anzeige die echte (gleichbleibende) Magazinzahl zeigt; beim Einschalten
  das Magazin der ausgerüsteten Waffe einmal füllen (sonst merkt das Spiel ein leeres Magazin und will nachladen).
- Der Prototyp kennt noch `DBG_INF_BULLET2` (Nachladen ohne Munition im Koffer, Wurfwaffen bleiben bei 5); passt
  nicht zum Wunsch „nie leer“, nicht vorgesehen.

### One-Hit-Kill: `DBG_EM_WEAK`

- `LifeDownSet2` setzt mit dem Bit den Schaden jedes Treffers auf das ganze Leben des Gegners. Gilt nur für Gegner,
  nicht für Leon und Partner (eigene Zweige davor).
- **Grenze:** einige Bosse und Teile rechnen Schaden selbst an diesem Weg vorbei (El Gigante em2b, der Boss aus
  mehreren Teilen em38, Hubschrauber em3a, em3c-Köpfe, Garrador-Klaue em10): dort bleibt es beim normalen Schaden.
  Bosse mit festen Phasen sind mit dem Bit nicht geprüft; vor dem Freigeben einmal jeden Bossraum am PC anspielen.
- Ein Treffer mit „mindestens 1 Leben lassen“ (Flag 1) bleibt bei 1, wie im Original.

## Die drei einmaligen Änderungen

Sie ändern Gegenstände bzw. Geld, also das, was beim nächsten Speichern im Spielstand steht. Ausschalten kann
sie nicht sinnvoll rückgängig machen (ausgegebenes Geld, eine inzwischen benutzte Waffe). Vorschlag: **Knöpfe
statt Schalter** („Holen“), nur bedienbar, wenn Leon spielt (`pG->pl_type == 0`; Ashley-Abschnitt,
Mercenaries und Ada haben keinen Koffer bzw. eigenes Geld). Ausführen im nächsten Bild auf dem Spiel-Thread,
nur wenn kein Untermenü offen ist (`STA_SUB_SCRN` aus).

### Killer7 mit 3/1/3/3

- Gegenstand **0x2A** (Leons Killer7, Modell `ss_wep17.dat`; 0x2B ist eine zweite Fassung). Die Höchststufen in
  `wep_level_info` sind für 0x2A genau `{3, 1, 3, 3}` (Feuerkraft, Feuerrate, Nachladen, Magazin): das gewünschte
  „3/1/3/3“ ist also voll ausgebaut. Gespeichert wird Stufe − 1: `setPowerLevel(2)`, `setSpeedLevel(0)`,
  `setReloadLevel(2)`, `setBulletLevel(2)`, dann Magazin voll (`WeaponId2ChargeNum(0x2A, 3)` = 14).
- Hat Leon schon einen Killer7, wird er nur auf 3/1/3/3 gebracht.
- `ItemMgr.get(0x2A, 0)` legt die Waffe ohne Platz an; Patch 0100 legt sie beim nächsten Öffnen des Koffers an
  die erste freie Stelle (im Koffer, sonst auf das Ablagefeld). Ist nirgends Platz, bleibt der Fehler des Originals
  (Waffe ohne Platz). Vorher prüfen und sonst „Kein Platz im Koffer“ melden.
- Munition (Magnum) gibt der Knopf nicht; mit „Unendlich Munition“ braucht es keine.

### Aktenkoffer L

- Koffer-Gegenstände: 0x7C (klein), 0x7D (M), **0x7E (L)**, 0x7F (XL). `SubScreenRoomInit` (`sscrn.cpp`) nimmt die
  Größe aus dem größten vorhandenen; der Händler kauft sie nicht zurück (`checkExerciseItem`).
- Umsetzung wie ein Kauf beim Händler (`ss_shop.cpp` `buyItem`) bzw. der Koffer-Editor des Prototyps
  (`ss_debug.cpp`): kleinere Koffer entfernen, `ItemMgr.get(0x7E, 0)`, `SubScreenWk.board_next = 2`; beim nächsten
  Öffnen wächst der Koffer (`ss_pzzl.cpp`, `board_size != board_next`) und behält die Anordnung.
- Hat Leon schon L oder XL, passiert nichts (kein Verkleinern).
- Zu prüfen: das Wachsen außerhalb des Händlers (der Weg ist derselbe, aber so nie ausgelöst).

### 1.000.000 Peseten

- Geld steht in `pG->peseta`; `addMoney` deckelt bei 99 999 999. Im Ashley-Abschnitt tauscht das Spiel
  `peseta` und `peseta_bak` (`PlSelect`), deshalb nur, wenn Leon spielt.
- Entschieden: jeder Druck `addMoney(1000000)`.

## Umsetzung (Vorschlag, wie die Spielsprache in R7)

- **App:** `CoreMenu.management()` bekommt ganz oben eine Überschrift „Cheats“ mit drei Umschaltern und drei
  Knöpfen (je drei pro Zeile wie die Sprachwahl), dazu ein Hinweistext („Gegenstände und Geld bleiben im
  Spielstand“). Texte in allen 10 Sprachen (`strings_ingame.xml`, `check_translations.py`), `CoreMenuLayoutTest`.
- **Weg in den Kern:** `CoreBridge.setCheats(int bits)` und `CoreBridge.cheatAction(int what)` →
  `core_mode.cpp` → `re4_core_set_cheats` / `re4_core_cheat_action` (`core_api.cpp`, `re4_core.h`), über den
  eigenen Kern-Prozess mit zwei neuen Nachrichten (`re4_core_ipc.h`, `host/coreproc.cpp`). Startwert
  `RE4_CHEATS=<bits>` in den Kern-Einstellungen, wie `RE4_GAME_LANGUAGE`.
- **Kern:** neue Datei `runtime/cheats.cpp` (mit den Spiel-Schaltern übersetzt wie `game_language.cpp`), ein
  Bild-Haken (`re4_add_frame_hook`): solange ein Schalter an ist, setzt er sein Bit in jedem Bild (so überlebt es
  Titel, Soft-Reset und das Laden eines Instant-Spielstands); beim Ausschalten löscht er es einmal (das
  Debug-Menü der Debug-Discs kann die Bits weiter selbst schalten). Einmalige Aktionen laufen im nächsten
  passenden Bild. Jede Aktion eine Zeile im Log (für Fehlerberichte: „cheat: …“).
- **Patch** nur für die Munitionsanzeige (`item.cpp` `bulletNum`, siehe oben).
- **Prüfen:** Laufzeittest mit Testhilfe (`RE4_TEST_CHEATS`), PC-Läufe in r100 (Schaden, Schießen, Treffer) und in
  den Bossräumen, die Koffer-Erweiterung als GX-Bild, Prüfstrecke Debug- und EU-Discs, Gerät.

## Entscheidungen des Projektinhabers (27.10.2026)

1. Killer7, Koffer L und Geld sind **einmalige Knöpfe**, keine Schalter (sie ändern den Spielstand dauerhaft).
2. Geld: **+1.000.000 Peseten je Druck** (Obergrenze des Spiels 99 999 999).
3. Unendlich Gesundheit **mit der Grenze** „Sofort-Tode in Szenen bleiben“.
4. Die drei Schalter werden **gespeichert** wie die übrigen Einstellungen des Ingame-Menüs (gelten nach einem
   App-Neustart weiter).
5. Das Cheat-Menü gibt es **mit beiden Disc-Arten** (mit den Debug-Discs kann das Debug-Menü des Spiels die Bits
   weiter selbst schalten).
6. Munitionsanzeige mit „Unendlich Munition“: **echte Magazinzahl** statt „100“ (Port-Patch auf `bulletNum`).

## Erweiterung 29.10.2026: automatische QTEs und Extra-Spiele

Wunsch des Projektinhabers (29.10.2026): eine **unterste Reihe mit zwei gleich breiten Knöpfen** unter den
bisherigen sechs.

- **„Automatic QTEs“ (Schalter, Bit 8):** Jede Tastenaufforderung (QTE) wird von selbst beantwortet, über denselben
  Weg wie „QTE per Tipp“ (`runtime/qte_touch.cpp`, `re4_qte_auto`): Tastenpaare (L+R, A+B) und einzelne Tasten zwei
  Bilder gedrückt, zwei los, solange die Aufforderung steht; Hämmern jedes zweite Bild. Ausgenommen: das einfache A
  (Türen, Leitern, Tritte), die Stick-Symbole und X („Ashley: verstecken“, eine Wahl des Spielers).
- **„Unlock extra games“ (Knopf 4, jederzeit):** setzt, was das Durchspielen setzt (`r333.cpp`): `EXT_HARD_MODE`
  (Titelmenü mit fünf Einträgen und anderem Hintergrund; Professional gehört zum selben Merker),
  `EXT_GET_OMAKE_ADA_GAME`, `EXT_GET_OMAKE_ETC_GAME` (beim ersten Mal die Mercenaries-Rekorde auf 0 wie dort). Nicht
  das Kostüm (`EXT_COSTUME`: ein neues Spiel würde danach fragen). Danach fragt die App „Spiel neu starten?“
  (Neustart oder Später); der Neustart behält die Sprache (`re4_core_restart_game(0)`). Die App merkt sich die
  Freischaltung (Bit 16): Der Kern setzt die Merker in jedem Bild wieder, solange eine Systemdatei ohne sie gelesen
  wurde (kein Speichern seither); beim nächsten Speichern landet sie auf der Speicherkarte.


## Erweiterung 03.11.2026: Spielfiguren für die Geschichte

Wunsch des Projektinhabers (03.11.2026): prüfen, welche Figuren die Hauptgeschichte statt Leon spielen können; jede, die
das sauber kann, kommt als eigener Abschnitt **„Player character“** unter die Cheat-Knöpfe und ersetzt Leon im
Einzelspieler-Spiel. Umgesetzt mit Patch 0195 (`port/whole/patches/0195-story-character.patch`) und
`runtime/cheats.cpp` (Abschnitt „the story's player character“), Branch `claude/char-cheat-f03122`.

### Was der Spielcode mitbringt

- `pG->pl_type` (0x4FB8, im Spielstand): 0 Leon, 1 Ashley, 2 Ada, 3 HUNK, 4 Krauser, 5 Wesker, 6 Leon+Ashley (nur das
  Debug-Startmenü, wird beim Start zu 0). Das Debug-Startmenü des Prototyps lässt jede Figur in jeden Raum: das Spiel
  hat für alle Figuren eigene Spielerklassen (`pl02`, `pl06`, `pl0a`, `pl0d`), Gegner reagieren auf sie (`em10.cpp`:
  Griffe, Tritte, Kopf je Figur), es gibt Gegner-Dateien je Figur (`EmFileTbl_Ada`, `_Wesker`, `_Klauser`).
- **Ohne Hilfe stürzt jede Figur außer Wesker im ersten Bild ab** (PC, Debug-Start, `RE4_TEST_PLAYER`, 27 Räume):
  Die Geschichte gibt Leons Startpaket (Pistole 0x23, Waffennummer 2); die Waffentabellen der Figuren (`read.cpp`
  `wep_data_ada/hunk/klauser/wesker`) haben nur ihre Mercenaries-Waffen, ohne Waffenmodul fehlt die Laufbewegung
  (`MotionSetCore(): pMot == NULL`). Wesker hat eine eigene Pistole (Nummer 2) und lief durch.
- Weiter fehlt den Figuren außerhalb ihrer eigenen Spiele: Leons Requisiten im Spieler-Archiv (Funkgerät 0x77..0x79,
  Raketenwerfer 0x70..0x76, Minen 0x72/0x73, Pfeife 0x7C; bei Wesker, Ada, Krauser leer oder anders belegt), Leons
  Körper für die Zwischensequenzen (`event.cpp` setzt `em/pl00/pl000a.bin` … nur bei `pl_type == 0`; sonst fehlt der
  Körper: „Event::ExePacket_SetOm : dat failed“), Leons linke Hände 2..5 (die Figuren kennen nur einige; eine fehlende
  Nummer wird als Zeiger genommen: Absturz), und die Gegenstände der Räume: jeder Raum-Gegenstand hat eine Maske
  `player_type` (1 Leon, 2 die anderen) – mit einer anderen Figur fehlten alle Gegenstände für Leon (Schlüssel, Munition,
  Schätze).

### Figuren: Ergebnis

| Figur | Ergebnis | Begründung |
| --- | --- | --- |
| HUNK (3) | **ja** | Archiv mit Leons Bewegungen (gleiches Skelett, gleiche Größen), hat sogar Leons Requisiten; mit Patch 0195 laufen alle Waffen Leons, Gegenstände, Zwischensequenzen |
| Krauser (4) | **ja** | eigene Bewegungen, Leons Waffen laufen; Raketenwerfer und Minenwerfer brauchen Leons Requisiten (an diesen Plätzen liegen Krausers Pfeile) |
| Wesker (5) | **ja** | Leons Bewegungen; eigene Pistole, Killer7 und Gewehr, sonst Leons Waffen; Funkgerät und Requisiten aus Leons Archiv |
| Ada (2) | **ja, mit Hinweis** | eigene, kleinere Figur: läuft in allen Räumen, Leons Waffen gehen; bei einigen Leon-Bewegungen fehlt ihr ein Körperteil („MotionMoveCore(): Pl, Invalid parts 110“: das Spiel überspringt nur dieses Teil) oder ein Zeitpunkt der Bewegungsfolge („MotSeqCtrl … Invalid Seq. Frame“, 6 Räume) – kleine Bewegungsfehler möglich, am Gerät ansehen |
| Ashley (1) | **nein** | keine Waffen, kein Koffer (`m_char` 1), das Spiel hat für sie eigene Abschnitte (r206–r20e); als Ersatz für Leon nicht spielbar |
| Leon+Ashley (6) | **nein** | keine Figur: ein Schalter des Debug-Startmenüs (Leon mit Ashley), wird beim Start zu Leon |
| Leons Kostüme | **nein (kein eigener Cheat)** | das Spiel wählt sie selbst (`PlSetCostume`: Weste, Kapitel 2 ohne Jacke, Spezialkostüm über `game_costume` und ein neues Spiel); die Stellvertreter folgen dieser Regel (Zwischensequenzen, Weste) |

### Umsetzung (Patch 0195, `runtime/cheats.cpp`)

- **Wahl:** Bits 32..224 der Cheat-Schalter = Spielertyp << 5 (2 Ada, 3 HUNK, 4 Krauser, 5 Wesker; 0 Leon). Sie reisen
  über den vorhandenen Weg (`CoreBridge.setCheats`, `RE4_CHEATS`, gespeichert wie die anderen Schalter); keine neue
  Schnittstelle. App: Abschnitt „Player character“ mit „Play as“ und fünf Knöpfen unter den Cheat-Knöpfen.
- **Wechsel beim Raumstart** (`gameRoomInit` vor `ReadPlayerData`): Leon → gewählte Figur, eine vom Cheat gesetzte Figur
  → Leon, wenn der Cheat aus ist. Nur in der Geschichte (nicht Assignment Ada, nicht Mercenaries), Ashleys Abschnitt bleibt
  Ashleys. Eine Änderung im Menü gilt seit 03.11.2026 sofort (Wunsch des Projektinhabers): der Raum startet neu, wo der Spieler steht (`switchNow`, wie eine Tür in den eigenen Raum); während eines Ereignisses ab dem nächsten Raum. Daneben der Schalter „Special costume (Leon/Ashley)“ (Bit 256, `game_costume` 1; aus: das normale Kostüm), ebenso sofort.
- **Leons Sachen bleiben:** Koffer, Leben (1200 + gelbe Kräuter), Geld, Kostüm (Leons Regel, auch die Weste schützt),
  die Gegenstände der Räume für Leon (`player_type` 1). Die Cheat-Knöpfe (Killer7, Koffer, Geld, Waffen) gehen auch mit
  einer Figur.
- **Spielstände:** `cGameSave::save` schreibt immer Leon (`pl_type` 0, sein Kostüm) – auch die Instant-Spielstände. Ein
  Spielstand lädt deshalb mit der Figur, die gerade im Menü gewählt ist (Leon bei „Leon“); Dolphin und GameCube sehen
  einen normalen Leon-Spielstand. Im Protokoll: „cheat: saved with Leon as the player (HUNK plays)“ und nach dem Laden
  „cheat: the story's player is HUNK from r100 on (was Leon)“.
- **Waffen:** eigene Dateien der Figur für Messer, Granaten und ihre Mercenaries-Waffen (Ada: Punisher, Gewehr, TMP; HUNK:
  TMP; Krauser: Bogen; Wesker: Pistole, Killer7, Gewehr), alle anderen aus Leons Tabelle. Leons Waffen verlangen linke
  Hände, die den Figuren fehlen: die nächstliegende eigene Hand. Im Koffer steht die Figur mit einer Leon-Waffe wie mit
  dem Messer da (kein eigenes Waffenmodell).
- **Leons Archiv** (`em/pl00.drs`, je Kostüm `pl08`/`pl09`/`pl10`) liegt bei einer Figur zusätzlich in der
  Entwickler-Hälfte von MEM1 (0x82000000, frei): Zwischensequenzen und Funkbildschirm zeigen **Leon** (ihre Bewegungen und
  Teile sind seine), Funkgerät, Raketenwerfer, Minen, Pfeife und fehlende Bewegungen kommen von dort.

### Krausers Bogen (0.99.10, Nutzerwunsch über den Projektinhaber, 11.11.2026)

- Kein Knopf (Entscheidung des Projektinhabers nach dem Test auf dem Retroid, 11.11.2026: „Krauser soll den Bogen von
  Haus aus bereits haben“): spielt Krauser die Geschichte, legt jeder Raumstart (`re4_story_char_room`,
  `runtime/cheats.cpp` `giveBow`) den Bogen (Gegenstand 0x52, Waffe 0x1C, Krausers eigene Datei) in den Koffer, falls
  er fehlt, und füllt die Pfeile (0x72, 20 je Feld) bis 40 auf; „Infinite ammo“ verbraucht keine. Der erste Stand
  (Cheat-Knopf 10 mit vier Texten) ist wieder entfernt.
- Leon und die anderen Stellvertreter haben keine Datei für Waffe 0x1C (`wep_data_leon` 0x1C leer): beim Raumstart
  (`re4_story_char_room`) verlassen Bogen und Pfeile den Koffer, sobald nicht Krauser spielt (Ashleys
  Abschnitt ausgenommen). Spielstände auf der Speicherkarte (Patch 0228, `cCard::makeSaveData`) enthalten sie nie;
  das laufende Spiel und der Fortsetzungspunkt behalten sie.

### Weskers Schalldämpfer (0.99.10, Antwort des Projektinhabers „Ja, einbauen“, 11.11.2026)

- Wie der Bogen: spielt Wesker die Geschichte, legt jeder Raumstart den Schalldämpfer (Gegenstand 0x3F, ein Teil wie
  Schaft und Zielfernrohr) in den Koffer, falls er fehlt, und setzt ihn auf die Pistole 0x23 (zusammen 0x24, Waffe 2
  Typ 1, Weskers eigene Datei `wep43` hat beide Modelle). Ohne Pistole 0x23 im Koffer gibt es keinen.
- Er passt auch auf Punisher (0x21 → 0x22) und Blacktail (0x27 → 0x28) mit Leons Dateien (Leons Debug-Ausrüstung 3 hat
  ihn mit beiden); setzt der Spieler ihn dort im Koffer an, bleibt er dort.
- Spielt jemand anderes (außer Ashleys Abschnitt): er verlässt beim Raumstart den Koffer, die Pistole, an der er war,
  ist wieder sie selbst (in der Hand ebenso, ohne Neuladen eines anderen Modells); Spielstände auf der Speicherkarte
  (Patch 0228) enthalten ihn nie, eine Pistole in der Hand mit Schalldämpfer wird im Spielstand zur Pistole ohne.
- Nebenwirkung: Leons Debug-Ausrüstung 3 (nur Debug-Discs, Debug-Menü) verliert ihren Schalldämpfer beim nächsten
  Raumstart und in Spielständen.

- **Nur wo Platz ist** (Bericht des Projektinhabers 11.11.2026: Gegenstände außerhalb des Koffers unsichtbar): Bogen,
  Pfeile und Schalldämpfer gehen wie ein gefundener Gegenstand in den Koffer (`PutInCase`), nie auf die Ablage daneben,
  die das Spiel nur beim Aufheben zeigt. Ohne Platz kommen sie beim nächsten Raumstart wieder; was frühere Stände auf
  der Ablage liegen ließen, sortiert der Raumstart neu ein.

### Grenzen (bewusst so)

- Zwischensequenzen, Funksprüche und Leons Stimme bleiben Leon; die Figur erscheint im Spiel selbst.
- Die Lebensanzeige zeigt für HUNK, Krauser und Wesker keinen Namen (das Spiel hat dort nur „Leon“, „Ashley“, „Ada“; wie
  in The Mercenaries).
- Im Koffer hält die Figur Leons Waffen nicht in der Hand.
- Spielstände merken sich die Figur nicht (Absicht: sie bleiben Leon-Spielstände).
