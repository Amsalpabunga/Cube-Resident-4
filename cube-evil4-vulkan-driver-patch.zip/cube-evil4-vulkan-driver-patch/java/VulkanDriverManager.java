package com.ast.re4decomp;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Custom Vulkan ICD packages in the format used by Winlator / Bannerlator / mali-panvk:
 *   meta.json  +  libvulkan_*.so
 *
 * Drivers live under filesDir/vulkan-drivers/<safe-id>/.
 * The active choice is stored in core_graphics as "vulkan_driver" (empty = system).
 *
 * Usage from CoreActivity:
 *   String path = VulkanDriverManager.activeLibraryPath(this, graphicsPrefs);
 *   // then append ";RE4_VULKAN_DRIVER=" + path  to the core settings string
 */
public final class VulkanDriverManager {
  private static final String TAG = "RE4Decomp";
  public static final String PREF_KEY = "vulkan_driver";   // inside GRAPHICS_PREFS ("core_graphics")
  private static final String DIR = "vulkan-drivers";

  private VulkanDriverManager() {}

  public static final class Driver {
    public final String id;          // folder name
    public final String name;        // from meta.json
    public final String description;
    public final String libraryName; // e.g. libvulkan_panfrost.so
    public final File soFile;        // absolute path of the .so
    public final int minApi;

    Driver(String id, String name, String description, String libraryName, File soFile, int minApi) {
      this.id = id;
      this.name = name;
      this.description = description;
      this.libraryName = libraryName;
      this.soFile = soFile;
      this.minApi = minApi;
    }

    @Override public String toString() { return name; }
  }

  /** Root folder that holds one subfolder per installed driver. */
  public static File root(Context ctx) {
    File f = new File(ctx.getFilesDir(), DIR);
    if (!f.isDirectory() && !f.mkdirs())
      Log.w(TAG, "cannot create " + f);
    return f;
  }

  /** Currently selected driver id, or "" for system libvulkan.so. */
  public static String selectedId(SharedPreferences graphics) {
    return graphics.getString(PREF_KEY, "");
  }

  public static void setSelectedId(SharedPreferences graphics, String id) {
    graphics.edit().putString(PREF_KEY, id == null ? "" : id).commit();
  }

  /**
   * Absolute path of the .so that native code should dlopen, or null for system.
   * Returns null also when the selected driver is missing / broken / API too low.
   */
  public static String activeLibraryPath(Context ctx, SharedPreferences graphics) {
    String id = selectedId(graphics);
    if (id.isEmpty()) return null;
    Driver d = find(ctx, id);
    if (d == null || !d.soFile.isFile()) return null;
    if (android.os.Build.VERSION.SDK_INT < d.minApi) {
      Log.w(TAG, "Vulkan driver " + id + " needs API " + d.minApi);
      return null;
    }
    return d.soFile.getAbsolutePath();
  }

  public static List<Driver> list(Context ctx) {
    File root = root(ctx);
    File[] kids = root.listFiles();
    if (kids == null) return Collections.emptyList();
    List<Driver> out = new ArrayList<>();
    for (File dir : kids) {
      if (!dir.isDirectory()) continue;
      Driver d = read(dir);
      if (d != null) out.add(d);
    }
    Collections.sort(out, (a, b) -> a.name.compareToIgnoreCase(b.name));
    return out;
  }

  public static Driver find(Context ctx, String id) {
    if (id == null || id.isEmpty()) return null;
    return read(new File(root(ctx), id));
  }

  private static Driver read(File dir) {
    File meta = new File(dir, "meta.json");
    if (!meta.isFile()) return null;
    try {
      String json = new String(readAll(meta), StandardCharsets.UTF_8);
      JSONObject o = new JSONObject(json);
      String name = o.optString("name", dir.getName());
      String desc = o.optString("description", "");
      String lib  = o.optString("libraryName", "libvulkan_panfrost.so");
      int minApi  = o.optInt("minApi", 31);
      File so = new File(dir, lib);
      if (!so.isFile()) return null;
      return new Driver(dir.getName(), name, desc, lib, so, minApi);
    } catch (Exception e) {
      Log.w(TAG, "bad driver meta in " + dir, e);
      return null;
    }
  }

  /**
   * Install a driver zip (meta.json + one .so). Returns the new Driver or throws.
   * Safe to call from a background thread.
   */
  public static Driver install(Context ctx, Uri zipUri) throws IOException {
    File root = root(ctx);
    File work = new File(root, ".work-" + System.currentTimeMillis());
    if (!work.mkdirs()) throw new IOException("cannot create work dir");
    try {
      String metaJson = null;
      String libraryName = null;
      try (InputStream in = ctx.getContentResolver().openInputStream(zipUri);
           ZipInputStream zis = new ZipInputStream(new BufferedInputStream(in))) {
        if (in == null) throw new IOException("cannot open zip");
        ZipEntry e;
        while ((e = zis.getNextEntry()) != null) {
          String name = e.getName();
          if (name.contains("..") || name.startsWith("/")) continue;
          // only top-level files
          int slash = name.lastIndexOf('/');
          if (slash >= 0) name = name.substring(slash + 1);
          if (name.isEmpty() || e.isDirectory()) continue;
          File out = new File(work, name);
          try (OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = zis.read(buf)) > 0) os.write(buf, 0, n);
          }
          if ("meta.json".equals(name)) {
            metaJson = new String(readAll(out), StandardCharsets.UTF_8);
          } else if (name.startsWith("lib") && name.endsWith(".so")) {
            libraryName = name;
          }
        }
      }
      if (metaJson == null) throw new IOException("zip has no meta.json");
      JSONObject o = new JSONObject(metaJson);
      if (libraryName == null) libraryName = o.optString("libraryName", "libvulkan_panfrost.so");
      File so = new File(work, libraryName);
      if (!so.isFile()) throw new IOException("zip missing " + libraryName);

      // id = safe version of the name
      String raw = o.optString("name", "driver");
      String id = raw.replaceAll("[^A-Za-z0-9._-]+", "_");
      if (id.length() > 64) id = id.substring(0, 64);
      if (id.isEmpty()) id = "driver";

      File target = new File(root, id);
      if (target.exists()) deleteRecursively(target);
      if (!work.renameTo(target)) throw new IOException("cannot activate driver folder");

      Driver d = read(target);
      if (d == null) throw new IOException("installed driver is unreadable");
      Log.i(TAG, "Vulkan driver installed: " + d.name + " → " + d.soFile);
      return d;
    } catch (Exception e) {
      deleteRecursively(work);
      if (e instanceof IOException) throw (IOException) e;
      throw new IOException(e.getMessage(), e);
    }
  }

  public static void uninstall(Context ctx, String id) throws IOException {
    if (id == null || id.isEmpty()) return;
    File dir = new File(root(ctx), id);
    if (dir.exists()) deleteRecursively(dir);
  }

  private static byte[] readAll(File f) throws IOException {
    try (InputStream in = new FileInputStream(f)) {
      byte[] buf = new byte[(int) f.length()];
      int off = 0;
      while (off < buf.length) {
        int n = in.read(buf, off, buf.length - off);
        if (n < 0) break;
        off += n;
      }
      return buf;
    }
  }

  private static void deleteRecursively(File f) throws IOException {
    if (f.isDirectory()) {
      File[] kids = f.listFiles();
      if (kids != null) for (File k : kids) deleteRecursively(k);
    }
    if (f.exists() && !f.delete()) throw new IOException("cannot delete " + f.getName());
  }
}
