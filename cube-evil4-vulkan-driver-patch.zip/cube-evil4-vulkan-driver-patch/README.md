# CubeEvil4 – Custom Vulkan Driver support (mali-panvk / Winlator format)

Patch that lets the APK install and use custom Vulkan ICD packages such as:

- `mali-panvk-27.0.0-devel-r10.zip`
- any other zip that contains `meta.json` + `libvulkan_*.so`

## What this does

1. User picks a driver zip via Storage Access Framework.
2. App extracts it under `filesDir/vulkan-drivers/<id>/`.
3. User selects the driver in the Display menu (next to Renderer).
4. On next start with Renderer = Vulkan the native code does  
   `dlopen("/data/.../libvulkan_panfrost.so")` instead of the system `libvulkan.so`.

## Files in this zip

```
java/VulkanDriverManager.java          ← NEW file, put in the same package
native/vulkan_bootstrap.cpp.patch      ← 1 small change in the existing file
docs/CoreActivity-changes.md           ← exact places to edit
docs/CoreMenu-changes.md               ← UI + Host interface
docs/SAF-install-snippet.md            ← optional document picker code
README.md                              ← this file
```

## Apply order

1. Copy `java/VulkanDriverManager.java` →  
   `port/android-decomp/app/src/main/java/com/ast/re4decomp/VulkanDriverManager.java`

2. Apply the change in `port/platform/android/vulkan_bootstrap.cpp`  
   (see the `.patch` file or the comment inside it).  
   Only the `dlopen` block needs to change.

3. Edit `CoreActivity.java` following `docs/CoreActivity-changes.md`.

4. Edit `CoreMenu.java` following `docs/CoreMenu-changes.md`  
   (and add the 4 string resources).

5. (Optional but recommended) Add the SAF launcher from `docs/SAF-install-snippet.md`  
   so the “Install from file…” button works.

6. Commit, push, let your GitHub Actions / workflow build the APK.

## Runtime behaviour

- Preference key: `core_graphics` → `vulkan_driver` (string, empty = system).
- Environment variable passed to the core: `RE4_VULKAN_DRIVER=/absolute/path/to/xxx.so`
- Native falls back to system `libvulkan.so` if the custom path fails to load.
- Selecting a custom driver automatically forces Renderer = Vulkan and restarts.

## Tested package format

```json
{
  "schemaVersion": 1,
  "name": "PanVK Mali Bifrost and Valhall (kbase) (Mesa 27.0.0-devel-58f2c55)",
  "libraryName": "libvulkan_panfrost.so",
  "minApi": 31,
  ...
}
```

Exactly the format of the `mali-panvk-27.0.0-devel-r10.zip` you provided.
