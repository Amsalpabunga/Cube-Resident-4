# Optional: Install-from-file with Storage Access Framework

In `CoreActivity` (or wherever you already handle document pickers for disc import):

```java
private final ActivityResultLauncher<Intent> vulkanDriverPicker =
    registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
      if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
      Uri uri = result.getData().getData();
      if (uri == null) return;
      // do the heavy work off the UI thread
      new Thread(() -> {
        try {
          VulkanDriverManager.Driver d = VulkanDriverManager.install(this, uri);
          // auto-select the newly installed driver
          runOnUiThread(() -> {
            SharedPreferences g = getSharedPreferences(GRAPHICS_PREFS, MODE_PRIVATE);
            g.edit()
                .putString(VulkanDriverManager.PREF_KEY, d.id)
                .putString(RENDERER, "vulkan")
                .putBoolean(VULKAN_STARTING, false)
                .commit();
            message("Installed: " + d.name);   // or your existing toast/dialog helper
            // optionally open the menu again or restart
            restartIntoGame("Vulkan driver " + d.name);
          });
        } catch (Exception e) {
          Log.e(TAG, "Vulkan driver install failed", e);
          runOnUiThread(() -> message("Install failed: " + e.getMessage()));
        }
      }, "vulkan-driver-install").start();
    });

/** Called from the menu "Install from file…" button. */
public void pickVulkanDriverZip() {
  Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
  i.addCategory(Intent.CATEGORY_OPENABLE);
  i.setType("application/zip");
  // also accept application/octet-stream for some file managers
  i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/octet-stream"});
  vulkanDriverPicker.launch(i);
}
```

Then from the Host / CoreMenu just call `pickVulkanDriverZip()` (expose it on the Host interface if needed).
