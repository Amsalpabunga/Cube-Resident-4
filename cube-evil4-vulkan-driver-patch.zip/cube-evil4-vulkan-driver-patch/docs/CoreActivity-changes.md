# CoreActivity.java changes

## 1. Replace the existing `withRenderer` method

Find (around line 3173):

```java
  static String withRenderer(String coreSettings, boolean vulkan) {
    StringBuilder out = new StringBuilder();
    for (String part : coreSettings.split(";")) {
      if (part.isEmpty() || part.startsWith("RE4_GX_API=")) continue;
      if (out.length() > 0) out.append(';');
      out.append(part);
    }
    if (vulkan) out.append(out.length() > 0 ? ";" : "").append("RE4_GX_API=vulkan");
    return out.toString();
  }
```

Replace with:

```java
  /** The core's settings with the renderer + optional custom Vulkan ICD path. */
  static String withRenderer(String coreSettings, boolean vulkan, String driverPath) {
    StringBuilder out = new StringBuilder();
    for (String part : coreSettings.split(";")) {
      if (part.isEmpty() || part.startsWith("RE4_GX_API=") || part.startsWith("RE4_VULKAN_DRIVER=")) continue;
      if (out.length() > 0) out.append(';');
      out.append(part);
    }
    if (vulkan) {
      out.append(out.length() > 0 ? ";" : "").append("RE4_GX_API=vulkan");
      if (driverPath != null && !driverPath.isEmpty())
        out.append(";RE4_VULKAN_DRIVER=").append(driverPath);
    }
    return out.toString();
  }

  // keep a 2-arg overload so any other call sites still compile
  static String withRenderer(String coreSettings, boolean vulkan) {
    return withRenderer(coreSettings, vulkan, null);
  }
```

## 2. Call site in onCreate / start sequence

Find the place that does (around line 322-324):

```java
    vulkan = chooseVulkan();
    coreSettings = withRenderer(coreSettings, vulkan);
```

Change to:

```java
    vulkan = chooseVulkan();
    String driverPath = null;
    if (vulkan) {
      driverPath = VulkanDriverManager.activeLibraryPath(this,
          getSharedPreferences(GRAPHICS_PREFS, MODE_PRIVATE));
      if (driverPath != null)
        Log.i(TAG, "renderer: custom Vulkan driver → " + driverPath);
    }
    coreSettings = withRenderer(coreSettings, vulkan, driverPath);
```

## 3. Host interface implementation (inside the anonymous Host)

Near the existing `rendererChanged` method add:

```java
    @Override public void vulkanDriverChanged(String id) {
      SharedPreferences g = getSharedPreferences(GRAPHICS_PREFS, MODE_PRIVATE);
      g.edit().putString(VulkanDriverManager.PREF_KEY, id == null ? "" : id).commit();
      // selecting a custom driver forces Vulkan
      if (id != null && !id.isEmpty())
        g.edit().putString(RENDERER, "vulkan").putBoolean(VULKAN_STARTING, false).commit();
      restartIntoGame("Vulkan driver " + (id == null || id.isEmpty() ? "system" : id));
    }

    @Override public java.util.List<VulkanDriverManager.Driver> vulkanDrivers() {
      return VulkanDriverManager.list(CoreActivity.this);
    }

    @Override public String vulkanDriverId() {
      return VulkanDriverManager.selectedId(getSharedPreferences(GRAPHICS_PREFS, MODE_PRIVATE));
    }
```
