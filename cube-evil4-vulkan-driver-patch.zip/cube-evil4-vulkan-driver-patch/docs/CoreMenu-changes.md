# CoreMenu.java changes

## 1. Extend the Host interface

Find the `Host` interface (where `rendererChanged`, `vulkanChosen`, etc. are declared) and add:

```java
    /** Custom Vulkan ICD id ("" = system libvulkan.so). Changing it restarts the game. */
    void vulkanDriverChanged(String id);

    /** Installed custom drivers (may be empty). */
    java.util.List<VulkanDriverManager.Driver> vulkanDrivers();

    /** Currently selected driver id, or "" for system. */
    String vulkanDriverId();
```

## 2. UI under the existing renderer() method

Right after the existing `renderer()` method body (after the help text for the renderer), add a new method or inline the following:

```java
  private void vulkanDriver() {
    final boolean supported = host != null && host.vulkanSupported();
    if (!supported) return;

    heading(R.string.ingame_vulkan_driver);   // "Vulkan driver"

    final String currentId = host.vulkanDriverId();
    final java.util.List<VulkanDriverManager.Driver> drivers = host.vulkanDrivers();

    // System entry
    Button sys = /* use your existing helper that adds a button to the current section */;
    // simplest if you have a method like parent.addButton(...):
    // Button sys = parent.addButton(s(R.string.ingame_vulkan_driver_system));
    // For the existing style that uses choices() / buttonsRow(), adapt accordingly.

    // Example using a plain button row (match the style of the rest of CoreMenu):
    MenuLayout.Buttons row = buttonsRow(body);
    Button sysBtn = toggleOrButton(row, s(R.string.ingame_vulkan_driver_system), currentId.isEmpty(),
        v -> {
          if (!currentId.isEmpty()) host.vulkanDriverChanged("");
        });
    // or just a normal Button that calls host.vulkanDriverChanged("")

    for (VulkanDriverManager.Driver d : drivers) {
      boolean selected = d.id.equals(currentId);
      Button b = /* add button with label d.name */;
      b.setOnClickListener(v -> {
        if (!selected) host.vulkanDriverChanged(d.id);
      });
      if (selected) b.setEnabled(false);
    }

    // Install button – wire this to a SAF picker in CoreActivity
    Button install = /* add button */;
    install.setText(s(R.string.ingame_vulkan_driver_install));
    install.setOnClickListener(v -> {
      // CoreActivity should expose a method that launches the document picker
      // and on result calls VulkanDriverManager.install(...) then refreshes the menu.
      if (host instanceof /* or cast */) {
        // host.pickVulkanDriverZip();  // you implement this
      }
    });

    indentedHelp(s(R.string.ingame_vulkan_driver_help));
  }
```

Call `vulkanDriver()` from the Display / Graphics page builder, right after the call to `renderer()`.

## 3. String resources to add

In `res/values/strings.xml` (and the other language files if you want):

```xml
<string name="ingame_vulkan_driver">Vulkan driver</string>
<string name="ingame_vulkan_driver_system">System</string>
<string name="ingame_vulkan_driver_install">Install from file…</string>
<string name="ingame_vulkan_driver_help">Install a mali-panvk / Winlator-style zip (meta.json + libvulkan_*.so). Needs a restart. Only used when Renderer = Vulkan.</string>
```
